if (typeof firebase === 'undefined') throw new Error('hosting/init-error: Firebase SDK not detected. You must include it before /__/firebase/init.js');
firebase.initializeApp({
  "apiKey": "AIzaSyByteRP532BlAgc7SveSyx2EtMOzT9o5Iw",
  "appId": "1:789249374221:web:7d3a0a4cd0e7389cf23d44",
  "authDomain": "techvision-rd-100059326.firebaseapp.com",
  "databaseURL": "",
  "messagingSenderId": "789249374221",
  "projectId": "techvision-rd-100059326",
  "storageBucket": "techvision-rd-100059326.firebasestorage.app"
});